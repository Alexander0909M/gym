Practicum Superstore — Nginx site

Host 2 (Ubuntu):
1. sudo apt update && sudo apt install -y nginx apache2-utils
2. Extract this archive on Host 2, cd into practicum-superstore-site
3. sudo cp default /etc/nginx/sites-available/default
4. sudo cp index.html 404.html 500.html /var/www/html/
5. sudo cp -r secure /var/www/html/
6. sudo chown -R www-data:www-data /var/www/html/secure
7. sudo chmod 750 /var/www/html/secure
8. sudo htpasswd -c /etc/nginx/.htpasswd admin
9. sudo chown root:www-data /etc/nginx/.htpasswd && sudo chmod 640 /etc/nginx/.htpasswd
10. sudo nginx -t && sudo systemctl restart nginx

Client Host 3: http://192.168.1.92/ and http://192.168.1.92/secure/
Server logs: sudo tail -f /var/log/nginx/access.log
Note: HTTP Basic auth is not encrypted without HTTPS. Use only in a lab.
